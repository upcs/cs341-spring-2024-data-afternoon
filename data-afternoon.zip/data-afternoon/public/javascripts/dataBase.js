
$.post("http://localhost:3000/", function(data, status) {

        document.getElementById("getDataBase").innerHTML = data; //database data 

})

    
